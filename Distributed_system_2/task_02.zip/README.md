Usage example:

Starter shell:
python Starter.py --x 0 --y 0 --z 0 --N 5 --k 3

Client shell:
python Client.py

